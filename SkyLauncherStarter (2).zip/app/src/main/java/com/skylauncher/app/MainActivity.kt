package com.skylauncher.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08121B)
private val Panel = Color(0xFF111F2A)
private val Green = Color(0xFF24D366)
private val Muted = Color(0xFF9DB0BF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary = Green, background = Bg, surface = Panel,
            onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
        )) { SkyLauncherApp() } }
    }
}

@Composable
private fun SkyLauncherApp() {
    var tab by remember { mutableStateOf("Home") }
    var account by remember { mutableStateOf("No profile selected") }
    var profileName by remember { mutableStateOf("") }
    var showLocalDialog by remember { mutableStateOf(false) }
    var selectedVersion by remember { mutableStateOf("Latest release (catalog not connected)") }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                listOf("Home", "Versions", "Mods", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            when (item) {
                                "Home" -> Icon(Icons.Default.Home, null)
                                "Versions" -> Icon(Icons.Default.ViewInAr, null)
                                "Mods" -> Icon(Icons.Default.Extension, null)
                                else -> Icon(Icons.Default.Settings, null)
                            }
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green, selectedTextColor = Green,
                            indicatorColor = Color(0xFF193A2A),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                .background(Bg)
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("▣", color = Green, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("SKY LAUNCHER", fontSize = 19.sp, fontWeight = FontWeight.Black)
                    Text("Minecraft Java launcher concept", color = Muted, fontSize = 11.sp)
                }
            }
            when (tab) {
                "Home" -> HomeScreen(account, selectedVersion, onPlay = {
                    // Safe prototype behavior: do not pretend to launch the game.
                    tab = "Versions"
                }, onLocal = { showLocalDialog = true }, onMicrosoft = {
                    account = "Microsoft sign-in not configured"
                })
                "Versions" -> VersionsScreen(selectedVersion) { selectedVersion = it }
                "Mods" -> ModsScreen()
                else -> SettingsScreen(account, onLocal = { showLocalDialog = true }, onMicrosoft = {
                    account = "Microsoft sign-in not configured"
                })
            }
        }
    }

    if (showLocalDialog) {
        AlertDialog(
            onDismissRequest = { showLocalDialog = false },
            title = { Text("Create local profile") },
            text = {
                Column {
                    Text("For offline profile selection only. This does not authenticate a Microsoft account.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = profileName, onValueChange = { profileName = it },
                        label = { Text("Player name") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (profileName.isNotBlank()) account = "Local: ${profileName.trim()}"
                    showLocalDialog = false
                }) { Text("Save profile") }
            },
            dismissButton = { TextButton(onClick = { showLocalDialog = false }) { Text("Cancel") } },
            containerColor = Panel
        )
    }
}

@Composable
private fun HomeScreen(
    account: String, version: String, onPlay: () -> Unit,
    onLocal: () -> Unit, onMicrosoft: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF173A2B)),
            shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("YOUR NEXT BLOCKY ADVENTURE", color = Green, fontSize = 11.sp,
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Build. Explore. Create.", fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("A clean launcher interface, ready to extend.", color = Muted)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) {
                    Text("OPEN VERSION MANAGER")
                }
            }
        }
        SectionTitle("Selected version")
        InfoCard("◆", version, "Real version catalog and game runtime are not connected yet.")
        SectionTitle("Account")
        InfoCard("●", account, "Local profile is a name-only offline profile.")
        OutlinedButton(onClick = onLocal, modifier = Modifier.fillMaxWidth()) {
            Text("Create local profile")
        }
        Button(onClick = onMicrosoft, modifier = Modifier.fillMaxWidth()) {
            Text("Set up Microsoft sign-in")
        }
        Text("Prototype only • Does not download or launch Minecraft yet",
            color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun VersionsScreen(selected: String, onSelect: (String) -> Unit) {
    val versions = listOf(
        "Latest release (catalog not connected)",
        "Latest snapshot (catalog not connected)",
        "Fabric profile (installer needed)",
        "Forge profile (installer needed)"
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Versions", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Choose a profile placeholder. Real versions must come from the official version manifest.",
            color = Muted)
        versions.forEach { version ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelect(version) },
                colors = CardDefaults.cardColors(
                    containerColor = if (selected == version) Color(0xFF193A2A) else Panel
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("▣", color = Green, fontSize = 24.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(version, fontWeight = FontWeight.SemiBold)
                        Text(if (selected == version) "Selected" else "Not installed",
                            color = Muted, fontSize = 12.sp)
                    }
                    if (selected == version) Text("✓", color = Green)
                }
            }
        }
        Text("Install / Play actions are intentionally placeholders until the game runtime and legal account flow are implemented.",
            color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ModsScreen() {
    val mods = listOf(
        "Fabric Loader" to "Mod loader profile • installer integration needed",
        "Forge" to "Mod loader profile • installer integration needed",
        "Sodium" to "Performance mod • compatible version required",
        "Mod files (.jar)" to "File picker and compatibility checks needed",
        "Resource packs" to "Folder management integration needed"
    )
    Column {
        Text("Mods & Add-ons", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Only use files from sources you trust.", color = Muted)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(mods) { (name, detail) ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("✦", color = Green, fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(name, fontWeight = FontWeight.Bold)
                            Text(detail, color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(account: String, onLocal: () -> Unit, onMicrosoft: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        InfoCard("●", "Account", account)
        OutlinedButton(onClick = onLocal, modifier = Modifier.fillMaxWidth()) {
            Text("Manage local profile")
        }
        Button(onClick = onMicrosoft, modifier = Modifier.fillMaxWidth()) {
            Text("Configure Microsoft sign-in")
        }
        InfoCard("▣", "Storage", "A safe app-specific storage folder should be configured.")
        InfoCard("⚙", "Memory", "RAM allocation depends on device limits and runtime support.")
        InfoCard("ⓘ", "About", "Sky Launcher starter • UI prototype v0.1.0")
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun InfoCard(icon: String, title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, color = Green, fontSize = 22.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, color = Muted, fontSize = 12.sp)
            }
        }
    }
}
