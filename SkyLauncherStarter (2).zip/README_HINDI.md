# Sky Launcher — Starter Project

यह **Android UI starter/prototype** है, तैयार Minecraft launcher या APK नहीं।

## इसमें अभी क्या काम करता है?
- Home, Versions, Mods और Settings स्क्रीन
- Local profile का नाम सेव करना (सिर्फ इस स्क्रीन की अस्थायी state में)
- Version/mod loader के लिए placeholder UI
- Dark + neon-green launcher design

## क्या अभी काम नहीं करता?
- Minecraft डाउनलोड/इंस्टॉल या गेम लॉन्च करना
- Latest version manifest से असली version list
- Microsoft OAuth/Xbox/Minecraft entitlement authentication
- Fabric/Forge installer चलाना या mod files की compatibility जांच
- Multiplayer server join करना, skins/capes, या mod downloads

इन सुविधाओं के लिए असली runtime, official version metadata, सुरक्षित Microsoft sign-in/OAuth configuration, और Java Edition लाइसेंस/entitlement जाँच जोड़नी होगी। Microsoft login को नकली बटन या सिर्फ player name से replace नहीं करना चाहिए। Local profile केवल offline UI profile है और Microsoft authentication नहीं है।

## APK बनाने के लिए
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में `SkyLauncher` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें (इंटरनेट चाहिए)।
4. `Build > Build APK(s)` चुनें।
5. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगी।

अगर केवल Android फोन है, तो इस ZIP से सीधे APK बनाना कठिन हो सकता है; Android Studio वाला कंप्यूटर सबसे आसान रास्ता है। यह प्रोजेक्ट अभी UI prototype है, इसलिए APK बन भी जाए तो Minecraft गेम लॉन्च नहीं करेगी।

## कानूनी/सुरक्षा नोट
Microsoft sign-in और Minecraft Java Edition access को आधिकारिक authentication तथा ownership checks के साथ लागू करें। अनजान mod/JAR फाइलें न चलाएँ। Minecraft और संबंधित ब्रांड उनके अपने अधिकारधारकों के हैं; यह एक स्वतंत्र, अनौपचारिक prototype है।
